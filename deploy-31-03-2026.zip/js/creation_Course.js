// ==========================================
// GESTIÓN DE CURSOS - courseConfig.js
// ==========================================

// Variables globales para almacenar datos
let courseData = {
    courseId: null,
    modules: [],
    userId: null,
    userName: null
};

let objectivesData = [];
let requirementsData = [];

// Helper: parsear JSON de forma segura, capturando respuestas con HTML de errores PHP
async function safeJsonParse(response) {
    const text = await response.text();
    try {
        return JSON.parse(text);
    } catch (e) {
        // Si la respuesta contiene HTML de errores PHP, extraer mensaje útil
        console.error('Respuesta no-JSON del servidor:', text);
        const cleanText = text.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
        throw new Error('Error en la solicitud: ' + (cleanText.substring(0, 150) || 'respuesta vacía'));
    }
}

// ==========================================
// FUNCIONES DE INICIALIZACIÓN
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    initializeForm();
    setupEventListeners();
    
    // Si estamos editando, cargar datos del curso
    const courseIdParam = new URLSearchParams(window.location.search).get('id');
    if (courseIdParam) {
        courseData.courseId = courseIdParam;
        loadCourseData(courseIdParam);
    }
});

function initializeForm() {
    const today = new Date().toISOString().split('T')[0];
    const startDateInput = document.getElementById('startDate');
    if (startDateInput) {
        startDateInput.value = today;
    }
    
    // Obtener datos de la sesión del usuario
    checkUserSession();
}

async function checkUserSession() {
    try {
        const response = await fetch('../api/check_session.php');
        const data = await response.json();
        
        if (data.loggedIn) {
            courseData.userId = data.user_id;
            courseData.userName = data.name;
            console.log('Usuario logueado:', data.name, 'ID:', data.user_id);
        } else {
            alert('Debes iniciar sesión para crear un curso');
            window.location.href = 'login.html';
        }
    } catch (error) {
        console.error('Error al verificar sesión:', error);
        alert('Error al verificar sesión');
    }
}

function setupEventListeners() {
    // Toggle para modo gratuito
    const isFreeCheckbox = document.getElementById('isFree');
    if (isFreeCheckbox) {
        isFreeCheckbox.addEventListener('change', toggleFreeMode);
    }

    // Drag and drop para imagen
    const uploadArea = document.querySelector('.image-upload');
    if (uploadArea) {
        uploadArea.addEventListener('dragover', handleDragOver);
        uploadArea.addEventListener('drop', handleImageDrop);
    }
}

// ==========================================
// FUNCIONES DE NAVEGACIÓN
// ==========================================
function switchSection(element, sectionId) {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    element.classList.add('active');

    document.querySelectorAll('.config-section').forEach(section => {
        section.classList.remove('active');
    });

    document.getElementById('section-' + sectionId).classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function goBack() {
    if (confirm('¿Estás seguro de salir? Los cambios no guardados se perderán.')) {
        window.location.href = '../index.html';
    }
}

// ==========================================
// FUNCIONES DE IMAGEN
// ==========================================
function previewImage(event) {
    const file = event.target.files[0];
    if (file) {
        validateImageFile(file);
    }
}

function handleDragOver(event) {
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.style.borderColor = '#1e3e5a';
    event.currentTarget.style.background = '#ebf4ff';
}

function handleImageDrop(event) {
    event.preventDefault();
    event.stopPropagation();
    const files = event.dataTransfer.files;
    if (files.length > 0) {
        const file = files[0];
        if (file.type.startsWith('image/')) {
            document.getElementById('courseImage').files = files;
            validateImageFile(file);
        }
    }
}

function validateImageFile(file) {
    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
        alert('La imagen no debe superar 5MB');
        return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
        const preview = document.getElementById('imagePreview');
        preview.src = e.target.result;
        preview.style.display = 'block';
    }
    reader.readAsDataURL(file);
}

// ==========================================
// FUNCIONES DE MÓDULOS
// ==========================================
function addModule() {
    const modulesList = document.getElementById('modulesList');
    const modules = document.querySelectorAll('.module-item');
    const moduleCount = modules.length + 1;
    const btnAdd = document.querySelector('.btn-add');

    const newModule = document.createElement('div');
    newModule.className = 'module-item';
    newModule.setAttribute('data-module-id', moduleCount);

    newModule.innerHTML = `
        <div class="module-header">
            <div class="module-header-info">
                <div class="module-number">${moduleCount}</div>
                <input type="text" class="module-title-input" placeholder="Título del módulo" required>
            </div>
            <div class="module-actions">
                <button type="button" class="icon-btn delete" title="Eliminar" onclick="removeModule(this)">🗑️</button>
            </div>
        </div>

        <div class="form-group">
            <label class="form-label">
                Duración de la Lección (Horas) <span class="required">*</span>
            </label>
            <input type="number" class="form-input module-duration" min="1" placeholder="Ej: 2" required>
            <span class="form-help">Duración en Horas</span>
        </div>
        
        <div class="form-group">
            <label class="form-label">
                Descripción <span class="required">*</span>
            </label>
            <textarea class="form-textarea module-description" maxlength="200" required></textarea>
            <span class="form-help">Máximo 200 caracteres</span>
        </div>

        <div class="form-group">
            <label class="form-label">
                Contenido <span class="required">*</span>
            </label>
            <textarea class="form-textarea module-content" required></textarea>
        </div>

        <div class="form-group">
            <label class="form-label">
                Complemento del módulo
            </label>
            <input type="text" class="form-input module-complement" placeholder="Ej: https://www.youtube.com/ o https://docs.google.com/document/" required>
            <span class="form-help">Pega un link de un archivo o un video</span>
        </div>
    `;

    modulesList.insertBefore(newModule, btnAdd);
}

function removeModule(button) {
    if (confirm('¿Estás seguro de eliminar este módulo?')) {
        const moduleItem = button.closest('.module-item');
        const lessonId = moduleItem.getAttribute('data-lesson-id');

        // Si tiene un lesson_id, eliminar del servidor
        if (lessonId) {
            fetch(`../api/delete_lesson.php/${lessonId}`, {
                method: 'DELETE'
            }).then(res => res.json())
              .then(data => {
                  if (data.error) console.error('Error al eliminar lección:', data.error);
                  else console.log('Lección eliminada del servidor');
              }).catch(err => console.error('Error:', err));
        }

        moduleItem.remove();
        updateModuleNumbers();
    }
}

function updateModuleNumbers() {
    document.querySelectorAll('.module-number').forEach((number, index) => {
        number.textContent = index + 1;
    });
}

// ==========================================
// FUNCIONES DE COSTO (TOGGLE)
// ==========================================
function toggleFreeMode(event) {
    const checkbox = event.target;
    const priceInput = document.getElementById('price');
    
    if (checkbox.checked) {
        priceInput.disabled = true;
        priceInput.value = '0';
        priceInput.style.opacity = '0.5';
    } else {
        priceInput.disabled = false;
        priceInput.style.opacity = '1';
    }
}

// ==========================================
// FUNCIONES DE ITEMS (OBJETIVOS Y REQUISITOS)
// ==========================================
function handleItemInput(event, type) {
    if (event.key !== 'Enter') return;
    event.preventDefault();

    const input = event.target;
    const itemText = input.value.trim();

    if (!itemText) {
        alert('Por favor escribe algo antes de presionar Enter');
        return;
    }

    if (type === 'objectives') {
        objectivesData.push(itemText);
        renderObjectives();
    } else if (type === 'requirements') {
        requirementsData.push(itemText);
        renderRequirements();
    }

    input.value = '';
    input.focus();
}

function renderObjectives() {
    const container = document.getElementById('objectivesList');
    container.innerHTML = '';
    objectivesData.forEach((objective, index) => {
        const tag = document.createElement('div');
        tag.className = 'item-tag';
        tag.innerHTML = `
            <span class="item-tag-text">✓ ${objective}</span>
            <span class="item-remove" onclick="removeObjective(${index})" title="Eliminar">×</span>
        `;
        container.appendChild(tag);
    });
}

function renderRequirements() {
    const container = document.getElementById('requirementsList');
    container.innerHTML = '';
    requirementsData.forEach((requirement, index) => {
        const tag = document.createElement('div');
        tag.className = 'item-tag';
        tag.innerHTML = `
            <span class="item-tag-text">✓ ${requirement}</span>
            <span class="item-remove" onclick="removeRequirement(${index})" title="Eliminar">×</span>
        `;
        container.appendChild(tag);
    });
}

function removeObjective(index) {
    objectivesData.splice(index, 1);
    renderObjectives();
}

function removeRequirement(index) {
    requirementsData.splice(index, 1);
    renderRequirements();
}

// ==========================================
// VALIDACIÓN DE FORMULARIO
// ==========================================
function validateForm() {
    const errors = {};

    // Validar campos generales
    const courseTitle = document.getElementById('courseTitle')?.value?.trim();
    if (!courseTitle) errors.courseTitle = 'El título es requerido';

    const shortDescription = document.getElementById('shortDescription')?.value?.trim();
    if (!shortDescription) errors.shortDescription = 'La descripción es requerida';

   // const instructor = document.getElementById('instructor')?.value?.trim();
    //if (!instructor) errors.instructor = 'El instructor es requerido';

    const category = document.getElementById('category')?.value;
    if (!category) errors.category = 'La categoría es requerida';

    const duration = document.getElementById('duration')?.value;
    if (!duration || duration < 1) errors.duration = 'La duración es requerida';

    //const introVideoUrl = document.getElementById('introVideoUrl')?.value?.trim();
    //if (!introVideoUrl) errors.introVideoUrl = 'El video de introducción es requerido';

    // Mostrar errores
    Object.keys(errors).forEach(fieldId => {
        const errorElement = document.getElementById(`error-${fieldId}`);
        const field = document.getElementById(fieldId);
        if (errorElement) {
            errorElement.classList.add('show');
        }
        if (field) {
            field.classList.add('error');
        }
    });

    return Object.keys(errors).length === 0;
}

// ==========================================
// FUNCIONES DE GUARDADO
// ==========================================
async function saveCourse() {
    if (!validateForm()) {
        alert('Por favor completa todos los campos requeridos');
        return;
    }

    const btn = document.getElementById('saveCourseBtn');
    const originalText = btn.innerHTML;
    btn.innerHTML = '⏳ Guardando...';
    btn.disabled = true;

    const isEditing = !!courseData.courseId;

    try {
        let courseId;

        if (isEditing) {
            // MODO EDICIÓN: usar APIs de update
            courseId = courseData.courseId;

            // 1. Actualizar curso principal
            await updateCourseMain(courseId);

            // 2. Actualizar detalles del curso
            await updateCourseDetails(courseId);

            // 3. Actualizar lecciones (eliminar existentes y recrear)
            await updateLessons(courseId);

        } else {
            // MODO CREACIÓN: usar APIs de add
            const courseMainData = await saveCourseMain();
            if (!courseMainData.courseId) {
                throw new Error(courseMainData.error || 'Error al guardar el curso');
            }
            courseId = courseMainData.courseId;
            courseData.courseId = courseId;

            await saveCourseDetails(courseId);
            await saveLessons(courseId);
        }

        showSuccessMessage(btn, originalText);
    } catch (error) {
        console.error('Error:', error);
        alert('Error al guardar el curso: ' + error.message);
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}

// ==========================================
// FUNCIONES API - AGREGAR CURSO
// ==========================================
async function saveCourseMain() {
    const formData = new FormData();
    
    // Mapeo de campos para compatibilidad con add_course.php existente
    formData.append('title', document.getElementById('courseTitle').value);
    formData.append('description', document.getElementById('shortDescription').value);
    formData.append('instructor_id', courseData.userId); // Usar el ID del usuario logueado
    formData.append('category', document.getElementById('category').value);
    formData.append('price', document.getElementById('isFree').checked ? 0 : document.getElementById('price').value);
    formData.append('duration', document.getElementById('duration').value);
    formData.append('rating', 0); // Rating inicial
    formData.append('students', 0); // Estudiantes iniciales
    formData.append('avatar', 'photos/usuario_sin_imagen.png'); // Avatar por defecto

    // Agregar imagen si existe (adjuntar el archivo binario real)
    const imageFile = document.getElementById('courseImage').files[0];
    if (imageFile) {
        formData.append('courseImageFile', imageFile);
    }

    try {
        const response = await fetch('../api/add_course.php', {
            method: 'POST',
            body: formData
        });

        const data = await safeJsonParse(response);
        return data;
    } catch (error) {
        throw new Error('Error en la solicitud: ' + error.message);
    }
}

// ==========================================
// FUNCIONES API - AGREGAR DETALLES DEL CURSO
// ==========================================
async function saveCourseDetails(courseId) {
    const payload = {
        course_id: courseId,
        learning_objectives: objectivesData,  // Cambio: objetivos → learning_objectives
        requirements: requirementsData,        // Cambio: requisitos → requirements
        intro_video: document.getElementById('introVideoUrl').value,  // Cambio: intro_video_url → intro_video
        recursos: document.getElementById('recursosUrl').value
    };

    try {
        const response = await fetch('../api/add_course_detail.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        const data = await safeJsonParse(response);
        if (!data.success && data.error) {
            throw new Error(data.error || 'Error al guardar detalles');
        }
        return data;
    } catch (error) {
        throw new Error('Error al guardar detalles: ' + error.message);
    }
}

// ==========================================
// FUNCIONES API - AGREGAR LECCIONES (MÓDULOS)
// ==========================================
async function saveLessons(courseId) {
    const modules = document.querySelectorAll('.module-item');
    
    for (let i = 0; i < modules.length; i++) {
        const module = modules[i];
        
        // Usar FormData porque add_lesson.php espera POST
        const formData = new FormData();
        formData.append('course_id', courseId);
        formData.append('order_number', i + 1);  // Cambio: lesson_number → order_number
        formData.append('title', module.querySelector('.module-title-input').value);
        formData.append('duration', module.querySelector('.module-duration').value);
        formData.append('description', module.querySelector('.module-description').value);
        formData.append('content', module.querySelector('.module-content').value);
        formData.append('video_url', module.querySelector('.module-complement').value);  // Cambio: complement_url → video_url
        formData.append('is_free', 0);

        try {
            const response = await fetch('../api/add_lesson.php', {
                method: 'POST',
                body: formData
            });

            const data = await safeJsonParse(response);
            if (!data.success && data.error) {
                throw new Error(`Error al guardar lección ${i + 1}: ${data.error}`);
            }
        } catch (error) {
            throw new Error('Error al guardar lecciones: ' + error.message);
        }
    }
}

// ==========================================
// FUNCIONES API - ACTUALIZAR CURSO (EDICIÓN)
// ==========================================
async function updateCourseMain(courseId) {
    const formData = new FormData();
    formData.append('id', parseInt(courseId));
    formData.append('title', document.getElementById('courseTitle').value);
    formData.append('description', document.getElementById('shortDescription').value);
    formData.append('category', document.getElementById('category').value);
    formData.append('price', document.getElementById('isFree').checked ? 0 : parseInt(document.getElementById('price').value) || 0);
    formData.append('duration', document.getElementById('duration').value + ' horas');

    // Agregar imagen si se seleccionó una nueva
    const imageFile = document.getElementById('courseImage').files[0];
    if (imageFile) {
        formData.append('courseImageFile', imageFile);
    }

    const response = await fetch('../api/update_course.php', {
        method: 'POST',
        body: formData
    });

    const data = await safeJsonParse(response);
    if (data.error) throw new Error(data.error);
    return data;
}

async function updateCourseDetails(courseId) {
    const payload = {
        course_id: parseInt(courseId),
        learning_objectives: objectivesData,
        requirements: requirementsData,
        intro_video: document.getElementById('introVideoUrl').value,
        recursos: document.getElementById('recursosUrl').value
    };

    const response = await fetch('../api/update_detail_course.php', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });

    const data = await safeJsonParse(response);
    if (data.error) {
        // Si no existe el detalle, crear uno nuevo
        console.warn('Update detail falló, intentando crear:', data.error);
        return await saveCourseDetails(courseId);
    }
    return data;
}

async function updateLessons(courseId) {
    const modules = document.querySelectorAll('.module-item');

    // Separar módulos existentes (con data-lesson-id) de nuevos
    for (let i = 0; i < modules.length; i++) {
        const module = modules[i];
        const lessonId = module.getAttribute('data-lesson-id');

        if (lessonId) {
            // Actualizar lección existente
            const payload = {
                lesson_id: parseInt(lessonId),
                title: module.querySelector('.module-title-input').value,
                duration: parseInt(module.querySelector('.module-duration').value) || 0,
                description: module.querySelector('.module-description').value,
                content: module.querySelector('.module-content').value,
                video_url: module.querySelector('.module-complement').value,
                order_number: i + 1
            };

            const response = await fetch(`../api/update_lesson.php?lesson_id=${lessonId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            const data = await safeJsonParse(response);
            if (data.error) {
                throw new Error(`Error al actualizar lección ${i + 1}: ${data.error}`);
            }
        } else {
            // Crear nueva lección
            const formData = new FormData();
            formData.append('course_id', courseId);
            formData.append('order_number', i + 1);
            formData.append('title', module.querySelector('.module-title-input').value);
            formData.append('duration', module.querySelector('.module-duration').value);
            formData.append('description', module.querySelector('.module-description').value);
            formData.append('content', module.querySelector('.module-content').value);
            formData.append('video_url', module.querySelector('.module-complement').value);
            formData.append('is_free', 0);

            const response = await fetch('../api/add_lesson.php', {
                method: 'POST',
                body: formData
            });

            const data = await safeJsonParse(response);
            if (data.error) {
                throw new Error(`Error al crear lección ${i + 1}: ${data.error}`);
            }
        }
    }
}

// ==========================================
// FUNCIONES DE UTILIDAD
// ==========================================
function showSuccessMessage(btn, originalText) {
    btn.innerHTML = '✓ Guardado';
    setTimeout(() => {
        btn.innerHTML = originalText;
        btn.disabled = false;
        alert('✓ Curso guardado exitosamente');
        window.location.href = '../index.html';
    }, 1500);
}

async function loadCourseData(courseId) {
    try {
        console.log('Cargando datos del curso:', courseId);

        const response = await fetch(`../api/get_full_course.php?id=${encodeURIComponent(courseId)}`);
        if (!response.ok) throw new Error('No se pudo cargar el curso');

        const data = await response.json();
        if (data.error) throw new Error(data.error);

        // Actualizar título del header
        const headerTitle = document.querySelector('.header-title h1');
        if (headerTitle) headerTitle.textContent = 'Editando: ' + data.title;

        // Cambiar texto del botón guardar
        const saveBtn = document.getElementById('saveCourseBtn');
        if (saveBtn) saveBtn.innerHTML = '💾 Actualizar Curso';

        // --- Sección General ---
        document.getElementById('courseTitle').value = data.title || '';
        document.getElementById('shortDescription').value = data.description || '';

        const categorySelect = document.getElementById('category');
        if (categorySelect && data.category) {
            // Intentar seleccionar por valor exacto, si no, buscar por texto
            const optionByValue = categorySelect.querySelector(`option[value="${data.category}"]`);
            if (optionByValue) {
                categorySelect.value = data.category;
            } else {
                // Buscar por texto del option
                for (const opt of categorySelect.options) {
                    if (opt.text.toLowerCase() === data.category.toLowerCase()) {
                        categorySelect.value = opt.value;
                        break;
                    }
                }
            }
        }

        // Imagen de portada
        if (data.image) {
            const preview = document.getElementById('imagePreview');
            const imgSrc = data.image.startsWith('http') ? data.image : '../' + data.image;
            preview.src = imgSrc;
            preview.style.display = 'block';
        }

        // --- Sección Contenido ---
        const durationInput = document.getElementById('duration');
        if (durationInput && data.duration) {
            const durationNum = parseInt(data.duration);
            if (!isNaN(durationNum)) durationInput.value = durationNum;
        }

        const introVideoInput = document.getElementById('introVideoUrl');
        if (introVideoInput && data.intro_video) {
            introVideoInput.value = data.intro_video;
        }

        // Objetivos de aprendizaje
        if (Array.isArray(data.learning_objectives)) {
            objectivesData = [...data.learning_objectives];
            renderObjectives();
        }

        // Requisitos
        if (Array.isArray(data.requirements)) {
            requirementsData = [...data.requirements];
            renderRequirements();
        }

        // --- Sección Precio ---
        const priceInput = document.getElementById('price');
        const isFreeCheckbox = document.getElementById('isFree');
        if (priceInput && data.price !== undefined) {
            priceInput.value = data.price;
            if (parseInt(data.price) === 0 && isFreeCheckbox) {
                isFreeCheckbox.checked = true;
                priceInput.disabled = true;
                priceInput.style.opacity = '0.5';
            }
        }

        // --- Sección Módulos (Lecciones) ---
        if (Array.isArray(data.lessons) && data.lessons.length > 0) {
            const modulesList = document.getElementById('modulesList');
            const btnAdd = modulesList.querySelector('.btn-add');

            data.lessons.forEach(lesson => {
                const newModule = document.createElement('div');
                newModule.className = 'module-item';
                newModule.setAttribute('data-module-id', lesson.order_number || '');
                newModule.setAttribute('data-lesson-id', lesson.id);

                newModule.innerHTML = `
                    <div class="module-header">
                        <div class="module-header-info">
                            <div class="module-number">${lesson.order_number || ''}</div>
                            <input type="text" class="module-title-input" placeholder="Título del módulo" value="${(lesson.title || '').replace(/"/g, '&quot;')}" required>
                        </div>
                        <div class="module-actions">
                            <button type="button" class="icon-btn delete" title="Eliminar" onclick="removeModule(this)">🗑️</button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">
                            Duración de la Lección (Horas) <span class="required">*</span>
                        </label>
                        <input type="number" class="form-input module-duration" min="1" placeholder="Ej: 2" value="${lesson.duration || ''}" required>
                        <span class="form-help">Duración en Horas</span>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">
                            Descripción <span class="required">*</span>
                        </label>
                        <textarea class="form-textarea module-description" maxlength="200" required>${lesson.description || ''}</textarea>
                        <span class="form-help">Máximo 200 caracteres</span>
                    </div>

                    <div class="form-group">
                        <label class="form-label">
                            Contenido <span class="required">*</span>
                        </label>
                        <textarea class="form-textarea module-content" required>${lesson.content || ''}</textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">
                            Complemento del módulo
                        </label>
                        <input type="text" class="form-input module-complement" placeholder="Ej: https://www.youtube.com/ o https://docs.google.com/document/" value="${(lesson.video_url || '').replace(/"/g, '&quot;')}" required>
                        <span class="form-help">Pega un link de un archivo o un video</span>
                    </div>
                `;

                modulesList.insertBefore(newModule, btnAdd);
            });
        }

        console.log('✅ Datos del curso cargados correctamente');
    } catch (error) {
        console.error('Error al cargar datos:', error);
        alert('Error al cargar los datos del curso: ' + error.message);
    }
}

function previewCourse() {
    if (!validateForm()) {
        alert('Por favor completa los campos básicos primero');
        return;
    }
    alert('Abriendo vista previa del curso...');
}
